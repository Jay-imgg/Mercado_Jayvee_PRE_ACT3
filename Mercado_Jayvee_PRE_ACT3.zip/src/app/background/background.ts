import {
  Component,
  ElementRef,
  NgZone,
  OnDestroy,
  afterNextRender,
  inject,
  viewChild,
} from '@angular/core';

interface Strand {
  base: number;   // vertical position, 0..1 of the viewport height
  a1: number;     // main wave height (fraction of viewport height)
  a2: number;     // secondary wave height
  k1: number;     // wave cycles across the screen
  k2: number;
  s1: number;     // flow speed (radians per second)
  s2: number;
  phase: number;
  width: number;
  alpha: number;
  depth: number;  // 0 = far, 1 = near
  glow: boolean;
}

// Three depth layers: far strands are faint and slow, near strands are bright and glow
const LAYERS = [
  { count: 5, depth: 0.15, width: 1.2, alpha: 0.16, speed: 0.16, amp: 0.10, glow: false },
  { count: 5, depth: 0.55, width: 1.7, alpha: 0.26, speed: 0.26, amp: 0.13, glow: false },
  { count: 4, depth: 1.0, width: 2.4, alpha: 0.40, speed: 0.38, amp: 0.16, glow: true },
];

const rand = (min: number, max: number) => min + Math.random() * (max - min);

@Component({
  selector: 'app-background',
  templateUrl: './background.html',
  styleUrl: './background.css',
})
export class Background implements OnDestroy {
  private readonly zone = inject(NgZone);
  private readonly canvasRef = viewChild.required<ElementRef<HTMLCanvasElement>>('canvas');

  private canvas!: HTMLCanvasElement;
  private ctx!: CanvasRenderingContext2D;
  private gradient!: CanvasGradient;
  private readonly strands: Strand[] = this.build();

  private w = 0;
  private h = 0;
  private raf = 0;
  private t0 = 0;
  private p = 0;          // smoothed scroll progress 0..1
  private target = 0;     // raw scroll progress
  private maxScroll = 0;
  private reduced = false;
  private cleanups: (() => void)[] = [];

  constructor() {
    // Browser only; runs outside Angular so the animation never triggers change detection
    afterNextRender(() => this.zone.runOutsideAngular(() => this.init()));
  }

  ngOnDestroy() {
    this.stop();
    this.cleanups.forEach(fn => fn());
  }

  private build(): Strand[] {
    return LAYERS.flatMap(l =>
      Array.from({ length: l.count }, () => ({
        base: rand(0.04, 0.96),
        a1: l.amp * rand(0.6, 1.3),
        a2: l.amp * rand(0.2, 0.5),
        k1: rand(0.5, 1.4),
        k2: rand(1.4, 2.6),
        s1: l.speed * rand(0.7, 1.3),
        s2: l.speed * rand(0.4, 0.9),
        phase: rand(0, Math.PI * 2),
        width: l.width * rand(0.8, 1.2),
        alpha: l.alpha * rand(0.8, 1.15),
        depth: l.depth,
        glow: l.glow,
      }))
    );
  }

  private init() {
    this.canvas = this.canvasRef().nativeElement;
    const ctx = this.canvas.getContext('2d');
    if (!ctx) return;
    this.ctx = ctx;
    this.t0 = performance.now();

    const mq = window.matchMedia?.('(prefers-reduced-motion: reduce)');
    this.reduced = !!mq?.matches;

    this.resize(true);
    this.measure();
    this.onScroll();

    let queued = false;
    const onResize = () => {
      if (queued) return;
      queued = true;
      requestAnimationFrame(() => {
        queued = false;
        this.resize(false);
        this.measure();
        if (this.reduced) this.draw(10);
      });
    };
    const onVisibility = () => (document.hidden ? this.stop() : this.start());
    const onMotion = (e: MediaQueryListEvent) => {
      this.reduced = e.matches;
      if (this.reduced) {
        this.stop();
        this.draw(10);
      } else {
        this.start();
      }
    };

    window.addEventListener('resize', onResize, { passive: true });
    window.addEventListener('scroll', this.onScroll, { passive: true });
    document.addEventListener('visibilitychange', onVisibility);
    mq?.addEventListener('change', onMotion);
    this.cleanups.push(
      () => window.removeEventListener('resize', onResize),
      () => window.removeEventListener('scroll', this.onScroll),
      () => document.removeEventListener('visibilitychange', onVisibility),
      () => mq?.removeEventListener('change', onMotion),
    );

    if (typeof ResizeObserver !== 'undefined') {
      const ro = new ResizeObserver(() => this.measure());
      ro.observe(document.body);
      this.cleanups.push(() => ro.disconnect());
    }

    if (this.reduced) this.draw(10);
    else this.start();
  }

  private resize(force: boolean) {
    const w = window.innerWidth;
    const h = window.innerHeight;
    // Ignore small height changes (mobile address bar) so scrolling never reallocates the canvas
    if (!force && w === this.w && Math.abs(h - this.h) < 150) return;
    this.w = w;
    this.h = h;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    this.canvas.width = Math.round(w * dpr);
    this.canvas.height = Math.round(h * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // Lines fade out toward both screen edges
    const g = this.ctx.createLinearGradient(0, 0, w, 0);
    g.addColorStop(0, 'rgba(232, 38, 43, 0)');
    g.addColorStop(0.12, 'rgba(232, 38, 43, 1)');
    g.addColorStop(0.88, 'rgba(232, 38, 43, 1)');
    g.addColorStop(1, 'rgba(232, 38, 43, 0)');
    this.gradient = g;
  }

  private measure() {
    this.maxScroll = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
    this.onScroll();
  }

  private readonly onScroll = () => {
    this.target = this.maxScroll > 0 ? Math.min(1, Math.max(0, window.scrollY / this.maxScroll)) : 0;
  };

  private start() {
    if (this.raf || this.reduced) return;
    this.raf = requestAnimationFrame(this.loop);
  }

  private stop() {
    cancelAnimationFrame(this.raf);
    this.raf = 0;
  }

  private readonly loop = (now: number) => {
    this.p += (this.target - this.p) * 0.06; // eased scroll for a fluid parallax
    this.draw((now - this.t0) / 1000 + 10);
    this.raf = requestAnimationFrame(this.loop);
  };

  private draw(t: number) {
    const { ctx, w, h } = this;
    const twoPi = Math.PI * 2;
    const step = w < 700 ? 20 : 26;

    ctx.clearRect(0, 0, w, h);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = this.gradient;

    for (const s of this.strands) {
      const k1 = (twoPi * s.k1) / w;
      const k2 = (twoPi * s.k2) / w;
      const breathe = 1 + 0.25 * Math.sin(t * 0.11 + s.phase);
      const y0 =
        s.base * h +
        (0.5 - this.p) * h * 0.18 * s.depth +      // near strands move more as you scroll
        Math.sin(t * 0.07 + s.phase * 2) * h * 0.03; // slow vertical drift
      const shift = this.p * 5 * s.depth;

      ctx.beginPath();
      for (let x = -step; x <= w + step; x += step) {
        const y =
          y0 +
          s.a1 * h * breathe * Math.sin(x * k1 + t * s.s1 + s.phase + shift) +
          s.a2 * h * Math.sin(x * k2 - t * s.s2 + s.phase * 1.7 - shift * 0.6);
        if (x === -step) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }

      if (s.glow) {
        ctx.globalAlpha = s.alpha * 0.25;
        ctx.lineWidth = s.width * 5;
        ctx.stroke();
      }
      ctx.globalAlpha = s.alpha;
      ctx.lineWidth = s.width;
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }
}
